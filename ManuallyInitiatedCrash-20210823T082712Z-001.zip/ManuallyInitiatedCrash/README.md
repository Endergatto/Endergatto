Queste sono le istruzioni che ti aiuteranno a usare questo metodo.
Step 1: Estrai la cartella.
Step 2: Esegui Enable.
Step 3: Riavvia il PC.
Step 4: BOOM!
NOTE:
Attenzione
- Se non hai un PC con BlocScorr nella tastiera, il metodo non funzionerà. Neanche con la tastiera su schermo.
Funzione dei file:
- Enable CREA delle variabili nel registro di sistema che causano il crash quando premi Ctrl + BloccScorr
- Disable ELIMINA le variabili nel registro di sistema che causano il crash quando premi Ctrl + BloccScorr
- Se non hai creato le variabili eseguendo il file Enable, Disable non funzionerà e darà (probabilmente) un errore.